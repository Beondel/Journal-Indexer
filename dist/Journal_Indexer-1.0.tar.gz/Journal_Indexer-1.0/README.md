# Journal-Indexer
Index for storing and tagging journal entries
